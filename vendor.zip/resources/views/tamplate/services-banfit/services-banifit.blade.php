<section class="bulk-sms mask-sms padding-top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="bulk-thumb">
                        <img src="assets/images/bulk/bulk01.png" alt="bulk">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="bulk-content text-center text-sm-left">
                        <span>services Benefits</span>
                        <h2 class="title">what's Benefits Transaction SMS</h2>
                        <p>Mauris iaculis pede, tellus commodo justo. Ligula in tortmris libero lectus libero aliquet,
                        vestibulum aut nullloret ac sictus, id pede quis quisque lacinia consectetuer. uere eros
                        velit eu nec arcu, repellat urna ad odio nunc. Pharetra massa mauris aliquet posuere magna
                        ligula, pellentesque molestie et, maecenas ultricies, conubia aliquam mauris</p>
                        <ul class="bullet-list">
                            <li>
                                Vestibulum id rhoncus tempus
                            </li>
                            <li>
                                Tellus fermentum a aenean
                            </li>
                            <li>
                                Pulvinar cursus imperdiet
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>