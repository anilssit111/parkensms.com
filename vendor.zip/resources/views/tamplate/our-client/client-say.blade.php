 <!--=================Client Say================= -->
 <section class="client-say padding-bottom padding-top">
        <div class="container">
            <div class="section-header">
                <span class="cate">client feedback</span>
                <h2 class="title">Our Valuable Client Say About Parken Solution.</h2>
            </div>
            <div class="client-say-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="client-item">
                            <div class="client-thumb">
                                <a href="#0"><img src="assets/images/client/client02.jpg" alt="client"></a>
                            </div>
                            <div class="client-content">
                                <h4 class="title"><a href="#0">Manoj Kumar</a></h4>
                                <span>Business Man</span>
                                <blockquote>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod teodunt ut
                                    labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risuodo
                                    viverra maecenas accumsan lacus vel facilisis.
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="client-item">
                            <div class="client-thumb">
                                <a href="#0"><img src="assets/images/client/client03.jpg" alt="client"></a>
                            </div>
                            <div class="client-content">
                                <h4 class="title"><a href="#0">Amit kumar</a></h4>
                                <span>Business Man</span>
                                <blockquote>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod teodunt ut
                                    labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risuodo
                                    viverra maecenas accumsan lacus vel facilisis.
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="client-item">
                            <div class="client-thumb">
                                <a href="#0"><img src="assets/images/client/client04.jpg" alt="client"></a>
                            </div>
                            <div class="client-content">
                                <h4 class="title"><a href="#0">Rohit kumar</a></h4>
                                <span>Business Man</span>
                                <blockquote>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod teodunt ut
                                    labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risuodo
                                    viverra maecenas accumsan lacus vel facilisis.
                                </blockquote>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="client-pagination"></div>
            </div>
        </div>
    </section>
    <!--=================Client Say================= -->