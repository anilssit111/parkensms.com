<!--=================Bulk Sms================= -->
@include('tamplate.services-banfit.services-banifit')
    <!--=================Bulk Sms================= -->


    <!--=================price-bluk Sms================= -->
    @include('tamplate.bluk-sms-price.bluk-sms-price')
    <!--=================price Bulk Sms================= -->


     <!--=================Bulk Sms================= -->
     @include('tamplate.global-bulk.global-bluk')
    <!--=================Bulk Sms================= -->

    <!--=================Our Feature================= -->
    @include('tamplate.ourfeature.feature')
    <!--=================Our Feature================= -->

    <!-- testimonial-section start -->
    @include('tamplate.our-client.client-say')
    <!-- testimonial-section end -->



    <!--=================sponsor Section================= -->
    @include('tamplate.sponsor.sponsers')
    <!--=================sponsor Section================= -->


  