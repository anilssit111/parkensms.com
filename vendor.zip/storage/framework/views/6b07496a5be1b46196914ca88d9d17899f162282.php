<section class="feature-section padding-top padding-bottom">
        <div class="container">
            <div class="section-header">
                <span class="cate">our feature</span>
                <h2 class="title">Transaction SMS feature</h2>
            </div>
            <div class="feature-section-wrapper">
                <div class="feature-area">
                    <div class="feature-item">
                        <div class="icon">
                            <i class="flaticon-customer-service"></i>
                        </div>
                        <div class="feature-content">
                            <h5 class="title">100% SMS Delivery</h5>
                            <p>Amet mus venenatis dictucator amet, amet amet eget semi.
                                driving ptingoum.</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <div class="icon">
                            <i class="flaticon-newspaper"></i>
                        </div>
                        <div class="feature-content">
                            <h5 class="title">Unlimited Validity</h5>
                            <p>Amet mus venenatis dictucator amet, amet amet eget semi.
                                driving ptingoum.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-area">
                    <img src="assets/images/feature/feature01.png" alt="feature">
                </div>
                <div class="feature-area">
                    <div class="feature-item">
                        <div class="icon">
                            <i class="flaticon-money"></i>
                        </div>
                        <div class="feature-content">
                            <h5 class="title">lowest cost</h5>
                            <p>Amet mus venenatis dictucator amet, amet amet eget semi.
                                driving ptingoum.</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <div class="icon">
                            <i class="flaticon-newspaper-1"></i>
                        </div>
                        <div class="feature-content">
                            <h5 class="title">Delivery report</h5>
                            <p>Amet mus venenatis dictucator amet, amet amet eget semi.
                                driving ptingoum.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/ourfeature/feature.blade.php ENDPATH**/ ?>