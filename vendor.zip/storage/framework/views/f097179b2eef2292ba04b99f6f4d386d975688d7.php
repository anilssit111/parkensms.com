<section class="sms-testing padding-bottom padding-top bg-ash">
        <div class="container">
            <div class="section-header wow fadeInUp">
                <span class="cate">sms testing</span>
                <h2 class="title">Request For Online Demo</h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="testing-item wow fadeInUp" data-wow-delay=".3s">
                        <h4 class="title">send us your SMS text</h4>
                        <form class="testing-form">
                            <div class="form-group">
                                <input type="text" placeholder="Country">
                            </div>
                            <div class="form-group">
                                <input type="email" placeholder="Registration Email">
                            </div>
                            <div class="form-group">
                                <input type="tel" placeholder="Phone">
                            </div>
                            <div class="form-group">
                                <select vlaue="choose type">
                                <option value="">Choose type</option>
                                <option value="Bulk Message">Bulk Message</option>
                                <option value="Voice Call">Voice Call</option>
                                </select>
                            </div>
                            <div class="form-group w-100">
                                <textarea placeholder="SMS text write in here"></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Submit Now">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testing-item wow fadeInUp" data-wow-delay=".3s">
                        <h4 class="title">about our privacy</h4>
                        <p>Menenatis malesuada at vestibulum, proin at nudit iaculis nullam ut, massa hac, arcu adipiscing in vel ac amllicitudin tempus dictum donec lorem libero. Turpis integpendisse felis, consectetuer odio, volutpat consectetuer erat tortor over hhead to do comeing </p>
                        <ul class="bullet-list">
                            <li>
                                Vestibulum id rhoncus tempus
                            </li>
                            <li>
                                Tellus fermentum a aenean
                            </li>
                            <li>
                                Pulvinar cursus imperdiet
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/request-demo/request-demo.blade.php ENDPATH**/ ?>