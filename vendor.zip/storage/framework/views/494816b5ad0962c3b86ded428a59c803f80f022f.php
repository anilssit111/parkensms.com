
<?php $__env->startSection('tamplate'); ?>

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">bulk SMS services</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
            <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="#">Feature</a>
                </li>
                <li>
                    Bluk SMS Feature
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->

    <!--=================Our Service================= -->
    <?php echo $__env->make('tamplate.service.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Our Service================= -->

    <!--=================bluk sms plan================= -->
      <?php echo $__env->make('tamplate.bluk-sms-price.bluk-sms-price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================bluk sms plan================= -->

       <!--=================Our Offer================= -->
       <?php echo $__env->make('tamplate.what-we-offer.what-we-offer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Our Offer================= -->


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/feature/bulk-sms-feature.blade.php ENDPATH**/ ?>