<section class="bulk-sms padding-top padding-bottom">
        <div class="container">
            <div class="row flex-wrap-reverse align-items-center">
                <div class="col-lg-6">
                    <div class="bulk-content text-center text-sm-left">
                        <span>wellcome to bulk sms</span>
                        <h2 class="title">grobal Bulk SMS Service company</h2>
                        <p>Mauris iaculis pede, tellus commodo justo. Ligula in tortmris libero lectus libero aliquet,
                            vestibulum aut nullloret ac sictus, id pede quis quisque lacinia consectetuer. uere eros
                            velit eu nec arcu, repellat urna ad odio nunc. Doletiarcu eginrdum tiunt morbi, aenean dui
                            amet at mapro Sed quis nunc est justo, in in, elit lorem vulputate, suspendisse pellentesque
                            pede tpluptatem ut mattis, eros diam litora nullam. Ac cras, mollis quis maecenas urna
                            ullamper eros.</p> 
                        <a href="http://sms.par-ken.com/signup"  target="_blank" class="custom-button active">sign-up & start</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="bulk-thumb">
                        <img src="assets/images/bulk/bulk01.png" alt="bulk">
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/global-bulk/global-bluk.blade.php ENDPATH**/ ?>