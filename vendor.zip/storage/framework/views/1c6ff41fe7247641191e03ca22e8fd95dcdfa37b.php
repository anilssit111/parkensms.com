<!--=================Bulk Sms================= -->
<?php echo $__env->make('tamplate.services-banfit.services-banifit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Bulk Sms================= -->


    <!--=================price-bluk Sms================= -->
    <?php echo $__env->make('tamplate.bluk-sms-price.bluk-sms-price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================price Bulk Sms================= -->


     <!--=================Bulk Sms================= -->
     <?php echo $__env->make('tamplate.global-bulk.global-bluk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Bulk Sms================= -->

    <!--=================Our Feature================= -->
    <?php echo $__env->make('tamplate.ourfeature.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Our Feature================= -->

    <!-- testimonial-section start -->
    <?php echo $__env->make('tamplate.our-client.client-say', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- testimonial-section end -->



    <!--=================sponsor Section================= -->
    <?php echo $__env->make('tamplate.sponsor.sponsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================sponsor Section================= -->


  <?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/sms/sidebar/sidebar.blade.php ENDPATH**/ ?>