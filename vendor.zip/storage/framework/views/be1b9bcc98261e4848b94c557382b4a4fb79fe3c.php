<div class="sponsor-section bg-f3 padding-bottom padding-top" style="background-color:#40965238">
        <div class="container">
            <div class="sponsor-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken1.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken2.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken3.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken4.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken5.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken6.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken7.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="sponsor-thumb">
                            <img src="assets/images/sponsor/parken8.jpg" alt="Bulk-SMS-Voice-Call">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/sponsor/sponsers.blade.php ENDPATH**/ ?>