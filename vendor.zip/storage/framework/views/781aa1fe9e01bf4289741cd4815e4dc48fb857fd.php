
<?php $__env->startSection('tamplate'); ?>

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">Promotion Call</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="#">Voice Call</a>
                </li>
                <li>
                   Promotion Call
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->

   
        <!--=================Price Plan================= -->
        <?php echo $__env->make('tamplate.voice.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=================Price Plan================= -->

  
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp1\htdocs\parkensms\resources\views/tamplate/voice/voice-massege.blade.php ENDPATH**/ ?>